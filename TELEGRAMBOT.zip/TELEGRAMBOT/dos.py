def saluda():
    print("saludos humano")