# archivotron.py

# Definir listas de palabras directamente en arreglos (sets para búsquedas rápidas)
palabras_validas = {"hola", "mundo", "python", "telegram", "codigo","verde","amarillo","rojo"}
palabras_prohibidas = {"maldicion", "groseria", "insulto", "ofensa"}
palabras_especiales = {"robot", "inteligencia", "bot", "especial"}
