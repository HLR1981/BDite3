print("file one _name_ is set to: {}" .format(__name__))#ejemplo de como importar archivos
from dos import saluda
def main():
    saluda()

if __name__ == "_main_":
    main()